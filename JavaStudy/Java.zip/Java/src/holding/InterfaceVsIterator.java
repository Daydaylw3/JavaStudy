package holding;

import java.util.Iterator;

public class InterfaceVsIterator {

	public static void display(Iterator it) {
		
	}
	
	public static void main(String[] args) {
		
	}

}
