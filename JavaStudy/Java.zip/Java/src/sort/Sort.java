package sort;

public interface Sort {
	public void sort(int[] array);
}
