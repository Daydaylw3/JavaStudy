package innerclasses;

public interface Destination {
	String readLabel();
}
