package innerclasses;

public interface Contents {
	int value();
}
